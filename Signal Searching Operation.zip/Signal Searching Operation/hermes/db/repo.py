"""CRUD functions used by the CLI commands. Thin wrappers over asyncpg --
no ORM, since the schema is small and stable and every query here maps to
exactly one CLI command's need.

Every function takes a `client_slug` and operates on that client's own set
of tables (hermes_{client_slug}_{table} -- see schema.sql). Table names
can't be asyncpg placeholders, so they're built with an f-string -- safe
only because `_table()` validates client_slug against the known-clients
registry first, rejecting anything that isn't one of the 4 known slugs
before it ever reaches a query string.
"""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any
from uuid import UUID

import asyncpg

from hermes.config.campaigns import Campaign
from hermes.config.clients import validate_client_slug
from hermes.domain.models import SignalDraft


def _table(client_slug: str, name: str) -> str:
    validate_client_slug(client_slug)
    return f"hermes_{client_slug}_{name}"


# ---------------------------------------------------------------------------
# campaigns
# ---------------------------------------------------------------------------


async def upsert_campaigns(pool: asyncpg.Pool, campaigns: list[Campaign]) -> None:
    by_client: dict[str, list[Campaign]] = defaultdict(list)
    for c in campaigns:
        by_client[c.client_slug].append(c)

    async with pool.acquire() as conn:
        for client_slug, client_campaigns in by_client.items():
            table = _table(client_slug, "campaigns")
            await conn.executemany(
                f"""
                INSERT INTO {table}
                    (lane_slug, state_code, profession_group, source_category, score_threshold, depth, active)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (lane_slug) DO UPDATE SET
                    state_code = EXCLUDED.state_code,
                    profession_group = EXCLUDED.profession_group,
                    source_category = EXCLUDED.source_category,
                    score_threshold = EXCLUDED.score_threshold,
                    depth = EXCLUDED.depth,
                    active = EXCLUDED.active,
                    updated_at = now()
                """,
                [
                    (
                        c.lane_slug,
                        c.state_code,
                        c.profession_group.value,
                        c.source_category.value,
                        c.score_threshold,
                        c.depth,
                        c.active,
                    )
                    for c in client_campaigns
                ],
            )


async def get_campaign_by_slug(pool: asyncpg.Pool, client_slug: str, lane_slug: str) -> asyncpg.Record | None:
    table = _table(client_slug, "campaigns")
    return await pool.fetchrow(f"SELECT * FROM {table} WHERE lane_slug = $1", lane_slug)


async def get_active_campaigns_by_state(
    pool: asyncpg.Pool, client_slug: str, state_code: str
) -> list[asyncpg.Record]:
    table = _table(client_slug, "campaigns")
    return await pool.fetch(
        f"SELECT * FROM {table} WHERE state_code = $1 AND active = true", state_code.upper()
    )


async def get_active_campaigns(pool: asyncpg.Pool, client_slug: str) -> list[asyncpg.Record]:
    table = _table(client_slug, "campaigns")
    return await pool.fetch(f"SELECT * FROM {table} WHERE active = true")


# ---------------------------------------------------------------------------
# behive_missions
# ---------------------------------------------------------------------------


async def create_mission(
    pool: asyncpg.Pool, client_slug: str, campaign_id: UUID, mission_id: str, query_text: str, depth: int
) -> UUID:
    table = _table(client_slug, "behive_missions")
    row = await pool.fetchrow(
        f"""
        INSERT INTO {table} (campaign_id, mission_id, query_text, depth, status)
        VALUES ($1, $2, $3, $4, 'queued')
        RETURNING id
        """,
        campaign_id,
        mission_id,
        query_text,
        depth,
    )
    return row["id"]


async def get_in_flight_missions(pool: asyncpg.Pool, client_slug: str) -> list[asyncpg.Record]:
    table = _table(client_slug, "behive_missions")
    return await pool.fetch(f"SELECT * FROM {table} WHERE status IN ('queued', 'running')")


async def mark_mission_polled(
    pool: asyncpg.Pool, client_slug: str, mission_row_id: UUID, status: str, phase: str | None = None
) -> None:
    table = _table(client_slug, "behive_missions")
    await pool.execute(
        f"""
        UPDATE {table}
        SET status = $2, phase = $3, last_polled_at = now(), poll_attempts = poll_attempts + 1
        WHERE id = $1
        """,
        mission_row_id,
        status,
        phase,
    )


async def complete_mission(
    pool: asyncpg.Pool, client_slug: str, mission_row_id: UUID, raw_report: str, metrics: dict[str, Any]
) -> None:
    table = _table(client_slug, "behive_missions")
    await pool.execute(
        f"""
        UPDATE {table}
        SET status = 'completed', completed_at = now(), raw_report = $2, metrics = $3
        WHERE id = $1
        """,
        mission_row_id,
        raw_report,
        json.dumps(metrics),
    )


async def fail_mission(pool: asyncpg.Pool, client_slug: str, mission_row_id: UUID, error_message: str) -> None:
    table = _table(client_slug, "behive_missions")
    await pool.execute(
        f"""
        UPDATE {table}
        SET status = 'failed', last_polled_at = now(), poll_attempts = poll_attempts + 1, error_message = $2
        WHERE id = $1
        """,
        mission_row_id,
        error_message,
    )


async def get_campaign_by_id(pool: asyncpg.Pool, client_slug: str, campaign_id: UUID) -> asyncpg.Record | None:
    table = _table(client_slug, "campaigns")
    return await pool.fetchrow(f"SELECT * FROM {table} WHERE id = $1", campaign_id)


# ---------------------------------------------------------------------------
# signals + human_review_queue
# ---------------------------------------------------------------------------


async def insert_signal(pool: asyncpg.Pool, client_slug: str, draft: SignalDraft) -> UUID:
    table = _table(client_slug, "signals")
    row = await pool.fetchrow(
        f"""
        INSERT INTO {table} (
            campaign_id, mission_id,
            target_profession, target_profession_group, employment_sector, employer_type,
            retirement_system, account_type_relevance, organization_signal, individual_signal,
            campaign_segment, profession_match_confidence, profession_source_url,
            signal_type,
            social_source_score, social_evidence_score, jobsite_evidence_score, cross_source_score, total_score,
            verification_status, rejection_reason_code,
            state, source_url, event_date, claim_text, raw_claim
        )
        VALUES (
            $1, $2,
            $3, $4, $5, $6,
            $7, $8, $9, $10,
            $11, $12, $13,
            $14,
            $15, $16, $17, $18, $19,
            $20, $21,
            $22, $23, $24, $25, $26
        )
        RETURNING id
        """,
        draft.campaign_id,
        draft.mission_id,
        draft.target_profession,
        draft.target_profession_group.value if draft.target_profession_group else None,
        draft.employment_sector.value if draft.employment_sector else None,
        draft.employer_type,
        draft.retirement_system,
        draft.account_type_relevance,
        draft.organization_signal,
        draft.individual_signal,
        draft.campaign_segment,
        draft.profession_match_confidence.value if draft.profession_match_confidence else None,
        draft.profession_source_url,
        draft.signal_type.value if draft.signal_type else None,
        draft.scores.social_source_score,
        draft.scores.social_evidence_score,
        draft.scores.jobsite_evidence_score,
        draft.scores.cross_source_score,
        draft.scores.total,
        draft.verification_status.value,
        draft.rejection_reason_code.value if draft.rejection_reason_code else None,
        draft.state,
        draft.source_url,
        draft.event_date,
        draft.claim_text,
        json.dumps(draft.raw_claim),
    )
    return row["id"]


async def enqueue_for_review(pool: asyncpg.Pool, client_slug: str, signal_id: UUID) -> UUID:
    table = _table(client_slug, "human_review_queue")
    row = await pool.fetchrow(
        f"INSERT INTO {table} (signal_id) VALUES ($1) RETURNING id",
        signal_id,
    )
    return row["id"]


async def list_pending_review(pool: asyncpg.Pool, client_slug: str) -> list[asyncpg.Record]:
    view = _table(client_slug, "v_human_review_queue")
    return await pool.fetch(f"SELECT * FROM {view} WHERE queue_status = 'pending' ORDER BY queued_at")


# ---------------------------------------------------------------------------
# platform_search_failures
# ---------------------------------------------------------------------------


async def log_search_failure(
    pool: asyncpg.Pool,
    client_slug: str,
    campaign_id: UUID,
    mission_id: UUID | None,
    source_category: str,
    failure_type: str,
    message: str,
) -> None:
    table = _table(client_slug, "platform_search_failures")
    await pool.execute(
        f"""
        INSERT INTO {table} (campaign_id, mission_id, source_category, failure_type, message)
        VALUES ($1, $2, $3, $4, $5)
        """,
        campaign_id,
        mission_id,
        source_category,
        failure_type,
        message,
    )
