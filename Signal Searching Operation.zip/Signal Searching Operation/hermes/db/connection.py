"""Lazy asyncpg pool + one-time schema application.

A single module-level pool is fine here: every hermes CLI invocation is a
short-lived process (cron-triggered `run`/`process-missions`), not a long-
running server juggling concurrent request scopes.
"""

from __future__ import annotations

import os
from pathlib import Path

import asyncpg

SCHEMA_PATH = Path(__file__).resolve().parents[2] / "schema.sql"

_pool: asyncpg.Pool | None = None


async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(dsn=os.environ["DATABASE_URL"])
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


async def init_schema(pool: asyncpg.Pool) -> None:
    """Applies schema.sql. Every statement is CREATE ... IF NOT EXISTS, so
    this is safe to re-run against an already-initialized database.
    """
    await pool.execute(SCHEMA_PATH.read_text())
