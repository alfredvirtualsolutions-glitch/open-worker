"""In-flight dataclasses passed between pipeline stages before a row is
persisted. Field names mirror the `signals` table columns 1:1 so
`db.repo.insert_signal` can map a SignalDraft straight across.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from uuid import UUID

from hermes.domain.enums import (
    EmploymentSector,
    ProfessionGroup,
    ProfessionMatchConfidence,
    RejectionReason,
    SignalType,
    VerificationStatus,
)


@dataclass(slots=True)
class RawClaim:
    """One claim as returned by BeHive's get_report/search_knowledge."""

    text: str
    source_url: str
    published_at: date | None = None
    quality: float | None = None
    raw: dict = field(default_factory=dict)


@dataclass(slots=True)
class ScoreBreakdown:
    social_source_score: int = 0
    social_evidence_score: int = 0
    jobsite_evidence_score: int = 0
    cross_source_score: int = 0

    @property
    def total(self) -> int:
        return (
            self.social_source_score
            + self.social_evidence_score
            + self.jobsite_evidence_score
            + self.cross_source_score
        )


@dataclass(slots=True)
class SignalDraft:
    """A candidate signal, built up by classifier.py + scorer.py, then
    finalized by acceptance.py before being handed to db.repo.insert_signal.
    """

    campaign_id: UUID
    mission_id: UUID
    claim_text: str
    source_url: str
    raw_claim: dict

    target_profession: str | None = None
    target_profession_group: ProfessionGroup | None = None
    employment_sector: EmploymentSector | None = None
    employer_type: str | None = None
    retirement_system: str | None = None
    account_type_relevance: str | None = None
    organization_signal: str | None = None
    individual_signal: str | None = None
    campaign_segment: str | None = None
    profession_match_confidence: ProfessionMatchConfidence | None = None
    profession_source_url: str | None = None

    signal_type: SignalType | None = None
    state: str | None = None
    event_date: date | None = None

    scores: ScoreBreakdown = field(default_factory=ScoreBreakdown)

    verification_status: VerificationStatus = VerificationStatus.PENDING
    rejection_reason_code: RejectionReason | None = None
