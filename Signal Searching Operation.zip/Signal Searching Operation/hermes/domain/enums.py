"""Fixed vocabularies shared across config, classifier, scorer, and the DB schema.

Keep these in sync with the CHECK constraints in schema.sql — a value accepted
here but not in the DDL (or vice versa) fails loudly at insert time, which is
the point: bad classification should error, not rot silently in a text column.
"""

from enum import Enum


class ProfessionGroup(str, Enum):
    EDUCATION = "education"
    NURSING = "nursing"
    PHYSICIAN = "physician"
    FIRE_SERVICE = "fire_service"
    PUBLIC_EMPLOYEE = "public_employee"
    BUSINESS_OWNER = "business_owner"


class EmploymentSector(str, Enum):
    PUBLIC = "public"
    PRIVATE = "private"
    NONPROFIT = "nonprofit"
    SELF_EMPLOYED = "self_employed"
    BUSINESS_OWNER = "business_owner"
    UNKNOWN = "unknown"


class SourceCategory(str, Enum):
    OFFICIAL_SOURCES = "official_sources"
    NEWS_AND_PRESS = "news_and_press"
    LINKEDIN_PUBLIC = "linkedin_public"
    FACEBOOK_PUBLIC = "facebook_public"
    X_AND_THREADS = "x_and_threads"
    INSTAGRAM_AND_YOUTUBE = "instagram_and_youtube"
    JOB_BOARDS = "job_boards"
    OFFICIAL_CAREER_PAGES = "official_career_pages"
    BUSINESS_TRANSITION_SOURCES = "business_transition_sources"
    PUBLIC_FORUM_TRENDS = "public_forum_trends"


class ProfessionMatchConfidence(str, Enum):
    HIGH = "High"
    MODERATE = "Moderate"
    LOW = "Low"


class VerificationStatus(str, Enum):
    PENDING = "pending"
    VERIFIED_SIGNAL = "verified_signal"
    REJECTED = "rejected"
    ARCHIVED_RESEARCH = "archived_research"


class RejectionReason(str, Enum):
    """Why a record didn't reach verified_signal. Mirrors the client spec's
    rejection rules (section 10) plus the classifier/acceptance failure modes.
    """

    PROFESSION_NOT_CONFIRMED = "profession_not_confirmed"
    NO_EXPLICIT_SIGNAL = "no_explicit_signal"
    STATE_NOT_CONFIRMED = "state_not_confirmed"
    DATE_NOT_CONFIRMED = "date_not_confirmed"
    SOURCE_NOT_LIVE = "source_not_live"
    IDENTITY_UNCLEAR = "identity_unclear"
    BELOW_SCORE_THRESHOLD = "below_score_threshold"
    ANONYMOUS_SUBJECT = "anonymous_subject"


class SignalType(str, Enum):
    """Fixed vocabulary from the client spec (sections 9, 16). Phase 0 only
    populates the news/official-source subset; the rest exist so later phases
    (social, job-site) don't need a schema/enum change.
    """

    # official / news source signals
    RETIREMENT_ANNOUNCEMENT = "retirement_announcement"
    RETIREMENT_RECOGNITION = "retirement_recognition"
    EARLY_RETIREMENT_PROGRAM = "early_retirement_program"
    ORG_RESTRUCTURING = "org_restructuring"

    # social (later phase)
    SOCIAL_RETIREMENT_ANNOUNCEMENT = "social_retirement_announcement"
    SOCIAL_CAREER_EXIT = "social_career_exit"
    SOCIAL_FINAL_WORKDAY = "social_final_workday"
    SOCIAL_RETIREMENT_RECOGNITION = "social_retirement_recognition"
    SOCIAL_PENSION_QUESTION = "social_pension_question"
    SOCIAL_PRACTICE_SALE = "social_practice_sale"
    SOCIAL_BUSINESS_SALE = "social_business_sale"
    SOCIAL_SUCCESSION_ANNOUNCEMENT = "social_succession_announcement"

    # job-site (later phase)
    VERIFIED_JOB_TRANSITION_SIGNAL = "verified_job_transition_signal"
    JOBSITE_SUPPORTING_SOURCE = "jobsite_supporting_source"
    REJECTED_JOB_RESULT = "rejected_job_result"

    # never becomes an individual outreach lead
    MARKET_QUESTION_SIGNAL = "market_question_signal"
    ORGANIZATION_RESEARCH_JOB = "organization_research_job"
