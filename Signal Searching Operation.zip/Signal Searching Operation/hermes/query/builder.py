"""Turns a campaign (profession group + source lane + state) into the
research-topic strings submitted to BeHive.

BeHive's own Queen decomposes a topic into several search axes and 12-14
queries each (see ../../behive/README.md#architecture) — hermes doesn't need
to enumerate keyword combinations itself, just hand BeHive one well-scoped
topic per profession term in the lane.

Rollout scope: CA, TX, FL run the full 6-profession-group matrix; NV and AZ
run education only (K-12 plus colleges/universities). Only official_sources
and news_and_press have query hints defined — social/job-board lanes are a
later phase and raise NotImplementedError here rather than silently emitting
a vague query that would never surface a usable signal.
"""

from __future__ import annotations

from hermes.config.campaigns import Campaign
from hermes.domain.enums import ProfessionGroup, SourceCategory

STATE_NAMES: dict[str, str] = {
    "CA": "California",
    "TX": "Texas",
    "FL": "Florida",
    "NV": "Nevada",
    "AZ": "Arizona",
}

PROFESSION_TERMS: dict[ProfessionGroup, list[str]] = {
    ProfessionGroup.EDUCATION: [
        "K-12 public school teacher",
        "school principal",
        "school district superintendent",
        "school administrator",
        "community college instructor",
        "university professor",
    ],
    ProfessionGroup.NURSING: [
        "registered nurse",
        "nurse practitioner",
        "nursing director",
        "hospital nurse manager",
    ],
    ProfessionGroup.PHYSICIAN: [
        "physician",
        "medical practice owner",
        "medical director",
        "physician group partner",
    ],
    ProfessionGroup.FIRE_SERVICE: [
        "firefighter",
        "fire captain",
        "fire chief",
        "fire department battalion chief",
    ],
    ProfessionGroup.PUBLIC_EMPLOYEE: [
        "state government employee",
        "county government employee",
        "city government employee",
        "public agency administrator",
    ],
    ProfessionGroup.BUSINESS_OWNER: [
        "small business owner",
        "family business owner",
        "medium-sized business owner",
    ],
}

SOURCE_CATEGORY_HINTS: dict[SourceCategory, str] = {
    SourceCategory.OFFICIAL_SOURCES: (
        "prioritize school board meeting minutes, district press releases, "
        "and .gov/.edu domains"
    ),
    SourceCategory.NEWS_AND_PRESS: "prioritize local newspaper and news outlet coverage",
}

RETIREMENT_SIGNAL_HINT = (
    "explicit, current retirement, resignation-to-retire, or early-retirement-program "
    "announcements — not general career-history mentions"
)


def build_queries(campaign: Campaign) -> list[str]:
    """One BeHive research topic per profession term in the campaign's group."""
    profession_terms = PROFESSION_TERMS.get(campaign.profession_group)
    if not profession_terms:
        raise NotImplementedError(
            f"no query terms defined yet for profession_group={campaign.profession_group.value}"
        )

    source_hint = SOURCE_CATEGORY_HINTS.get(campaign.source_category)
    if source_hint is None:
        raise NotImplementedError(
            f"no query hint defined yet for source_category={campaign.source_category.value}"
        )

    state_name = STATE_NAMES.get(campaign.state_code, campaign.state_code)

    return [
        f"{state_name} {profession} retirement signals: {RETIREMENT_SIGNAL_HINT}. {source_hint}."
        for profession in profession_terms
    ]
