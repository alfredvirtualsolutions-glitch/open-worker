"""Loads and validates hermes/config/campaigns.yaml.

Validation happens here (not just at insert time) so a typo in the YAML fails
with a clear message pointing at the lane, instead of surfacing as an opaque
Postgres CHECK-constraint error during `seed-campaigns`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from hermes.config.clients import validate_client_slug
from hermes.domain.enums import ProfessionGroup, SourceCategory

DEFAULT_CAMPAIGNS_PATH = Path(__file__).with_name("campaigns.yaml")


@dataclass(frozen=True, slots=True)
class Campaign:
    lane_slug: str
    client_slug: str
    state_code: str
    profession_group: ProfessionGroup
    source_category: SourceCategory
    score_threshold: int = 50
    depth: int = 2
    active: bool = True


def campaign_from_record(row, client_slug: str) -> Campaign:
    """Rebuilds a Campaign from a hermes_{client_slug}_campaigns row (an
    asyncpg.Record). client_slug isn't a column on that table -- which
    table the row came from *is* the client -- so the caller must supply
    it (it already had to, to pick the table to query).
    """
    return Campaign(
        lane_slug=row["lane_slug"],
        client_slug=client_slug,
        state_code=row["state_code"],
        profession_group=ProfessionGroup(row["profession_group"]),
        source_category=SourceCategory(row["source_category"]),
        score_threshold=row["score_threshold"],
        depth=row["depth"],
        active=row["active"],
    )


class CampaignConfigError(ValueError):
    pass


def load_campaigns(path: Path | str = DEFAULT_CAMPAIGNS_PATH) -> list[Campaign]:
    path = Path(path)
    raw = yaml.safe_load(path.read_text()) or {}
    entries = raw.get("campaigns", [])
    if not entries:
        raise CampaignConfigError(f"{path} has no `campaigns` entries")

    campaigns: list[Campaign] = []
    seen_slugs: set[str] = set()
    for i, entry in enumerate(entries):
        lane_slug = entry.get("lane_slug")
        if not lane_slug:
            raise CampaignConfigError(f"campaigns[{i}] is missing lane_slug")
        if lane_slug in seen_slugs:
            raise CampaignConfigError(f"duplicate lane_slug: {lane_slug}")
        seen_slugs.add(lane_slug)

        try:
            client_slug = validate_client_slug(entry.get("client_slug", ""))
        except ValueError as exc:
            raise CampaignConfigError(f"{lane_slug}: {exc}") from exc

        try:
            profession_group = ProfessionGroup(entry["profession_group"])
        except (KeyError, ValueError) as exc:
            raise CampaignConfigError(
                f"{lane_slug}: invalid profession_group {entry.get('profession_group')!r}"
            ) from exc

        try:
            source_category = SourceCategory(entry["source_category"])
        except (KeyError, ValueError) as exc:
            raise CampaignConfigError(
                f"{lane_slug}: invalid source_category {entry.get('source_category')!r}"
            ) from exc

        state_code = entry.get("state_code", "")
        if len(state_code) != 2:
            raise CampaignConfigError(f"{lane_slug}: state_code must be a 2-letter code, got {state_code!r}")

        depth = int(entry.get("depth", 2))
        if not 1 <= depth <= 5:
            raise CampaignConfigError(f"{lane_slug}: depth must be between 1 and 5, got {depth}")

        campaigns.append(
            Campaign(
                lane_slug=lane_slug,
                client_slug=client_slug,
                state_code=state_code.upper(),
                profession_group=profession_group,
                source_category=source_category,
                score_threshold=int(entry.get("score_threshold", 50)),
                depth=depth,
                active=bool(entry.get("active", True)),
            )
        )
    return campaigns
