"""Registry of the LEADFORCE clients this hermes deployment serves.

Each client gets a fully separate set of 8 tables (hermes_{slug}_*, see
schema.sql) -- no shared campaigns/signals/etc. across clients. Adding a
client means: add the slug here, add its lanes to campaigns.yaml, and add
its 8 tables to schema.sql.
"""

from __future__ import annotations

CLIENTS: dict[str, str] = {
    "ryancahill": "Ryan Cahill",
    "dontowns": "Don Towns",
    "benjaminpersyn": "Benjamin Persyn",
    "juancabezas": "Juan Cabezas",
}


def validate_client_slug(client_slug: str) -> str:
    if client_slug not in CLIENTS:
        raise ValueError(f"unknown client_slug {client_slug!r}; known clients: {sorted(CLIENTS)}")
    return client_slug
