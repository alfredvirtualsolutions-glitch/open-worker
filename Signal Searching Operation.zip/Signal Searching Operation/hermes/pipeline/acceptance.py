"""The acceptance gate: the 7 conditions from README ("How a record becomes
a verified signal") applied in order. First failing condition wins and sets
a specific rejection_reason_code — a row never reaches human_review_queue
on a generic "didn't pass" basis.
"""

from __future__ import annotations

from hermes.domain.enums import RejectionReason, VerificationStatus
from hermes.domain.models import SignalDraft

# (predicate, rejection reason if the predicate is false) — order matches
# the numbered list in README, section "How a record becomes a verified signal".
_CHECKS: list[tuple[str, RejectionReason]] = [
    ("profession_confirmed", RejectionReason.PROFESSION_NOT_CONFIRMED),
    ("explicit_signal", RejectionReason.NO_EXPLICIT_SIGNAL),
    ("state_confirmed", RejectionReason.STATE_NOT_CONFIRMED),
    ("date_confirmed", RejectionReason.DATE_NOT_CONFIRMED),
    ("source_live", RejectionReason.SOURCE_NOT_LIVE),
    ("identity_clear", RejectionReason.IDENTITY_UNCLEAR),
    ("score_cleared", RejectionReason.BELOW_SCORE_THRESHOLD),
]


def evaluate_acceptance(
    draft: SignalDraft, *, score_threshold: int, source_still_live: bool
) -> VerificationStatus:
    """Mutates draft.verification_status / draft.rejection_reason_code in
    place and returns the resulting status.

    `source_still_live` is passed in rather than checked here because it
    requires a network call (an HTTP HEAD/GET against draft.source_url) —
    keeping this function pure makes it trivial to unit test the other six
    conditions without touching the network.
    """
    conditions = {
        "profession_confirmed": draft.profession_match_confidence is not None
        and bool(draft.profession_source_url),
        "explicit_signal": draft.signal_type is not None,
        "state_confirmed": bool(draft.state),
        "date_confirmed": draft.event_date is not None,
        "source_live": source_still_live,
        "identity_clear": bool(draft.individual_signal or draft.organization_signal),
        "score_cleared": draft.scores.total >= score_threshold,
    }

    for key, reason in _CHECKS:
        if not conditions[key]:
            draft.verification_status = VerificationStatus.REJECTED
            draft.rejection_reason_code = reason
            return draft.verification_status

    draft.verification_status = VerificationStatus.VERIFIED_SIGNAL
    draft.rejection_reason_code = None
    return draft.verification_status
