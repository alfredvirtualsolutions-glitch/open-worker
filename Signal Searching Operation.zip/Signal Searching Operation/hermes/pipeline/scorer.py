"""Turns a classified SignalDraft into a ScoreBreakdown.

The weights below are a working placeholder, not the client's real scoring
spec (README references "client spec section 21" for the authoritative
formula, which isn't in this repo yet). They're isolated here so tuning them
against the real spec later doesn't touch classifier.py, acceptance.py, or
the DB layer — only these four constants and `score_signal`.
"""

from __future__ import annotations

from hermes.domain.enums import ProfessionMatchConfidence, SignalType, SourceCategory
from hermes.domain.models import ScoreBreakdown, SignalDraft

SOURCE_CATEGORY_WEIGHTS: dict[SourceCategory, int] = {
    SourceCategory.OFFICIAL_SOURCES: 40,
    SourceCategory.NEWS_AND_PRESS: 30,
}
_DEFAULT_SOURCE_WEIGHT = 10

SIGNAL_TYPE_WEIGHTS: dict[SignalType, int] = {
    SignalType.RETIREMENT_ANNOUNCEMENT: 30,
    SignalType.EARLY_RETIREMENT_PROGRAM: 30,
    SignalType.RETIREMENT_RECOGNITION: 20,
    SignalType.ORG_RESTRUCTURING: 10,
}
_DEFAULT_SIGNAL_WEIGHT = 5

CONFIDENCE_BONUS: dict[ProfessionMatchConfidence, int] = {
    ProfessionMatchConfidence.HIGH: 15,
    ProfessionMatchConfidence.MODERATE: 8,
    ProfessionMatchConfidence.LOW: 3,
}

CROSS_SOURCE_POINTS_PER_CORROBORATION = 10
CROSS_SOURCE_SCORE_CAP = 25


def score_signal(
    draft: SignalDraft,
    source_category: SourceCategory,
    *,
    corroborating_sources: int = 0,
) -> ScoreBreakdown:
    """Scores in place (sets draft.scores) and returns the same breakdown."""
    source_score = SOURCE_CATEGORY_WEIGHTS.get(source_category, _DEFAULT_SOURCE_WEIGHT)

    signal_weight = (
        SIGNAL_TYPE_WEIGHTS.get(draft.signal_type, _DEFAULT_SIGNAL_WEIGHT) if draft.signal_type else 0
    )
    confidence_bonus = CONFIDENCE_BONUS.get(draft.profession_match_confidence, 0)
    evidence_score = signal_weight + confidence_bonus

    cross_score = min(
        corroborating_sources * CROSS_SOURCE_POINTS_PER_CORROBORATION, CROSS_SOURCE_SCORE_CAP
    )

    breakdown = ScoreBreakdown(
        social_source_score=source_score,
        social_evidence_score=evidence_score,
        jobsite_evidence_score=0,  # job-board lane is a later phase
        cross_source_score=cross_score,
    )
    draft.scores = breakdown
    return breakdown
