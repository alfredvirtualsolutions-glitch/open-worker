"""Maps one raw BeHive claim onto a SignalDraft: what profession it's about,
what kind of signal it is, who/what organization it names.

v0 heuristic: keyword and regex matching, not an LLM classifier. It's meant
to be replaced or tuned per-profession-group as later phases (nursing,
physician, ...) come online — the keyword tables below are the only things
that should need to change for that, not the control flow.
"""

from __future__ import annotations

import re
from datetime import date
from uuid import UUID

from hermes.domain.enums import (
    EmploymentSector,
    ProfessionGroup,
    ProfessionMatchConfidence,
    SignalType,
)
from hermes.domain.models import RawClaim, SignalDraft

# Checked in order; the first matching category wins so more specific signal
# types (early-retirement programs, org restructuring) aren't shadowed by the
# generic "retiring" keywords that also appear inside them.
_SIGNAL_TYPE_KEYWORDS: list[tuple[SignalType, tuple[str, ...]]] = [
    (
        SignalType.EARLY_RETIREMENT_PROGRAM,
        ("early retirement incentive", "early retirement program", "retirement incentive program", "buyout program"),
    ),
    (
        SignalType.ORG_RESTRUCTURING,
        ("district reorganization", "district restructuring", "district consolidation", "school closure plan"),
    ),
    (
        SignalType.RETIREMENT_RECOGNITION,
        ("retirement celebration", "retirement party", "honored for his retirement", "honored for her retirement", "honored for their retirement"),
    ),
    (
        SignalType.RETIREMENT_ANNOUNCEMENT,
        (
            "announced his retirement", "announced her retirement", "announced their retirement",
            "will retire", "plans to retire", "set to retire", "retiring at the end of",
            "retiring after", "to step down and retire",
        ),
    ),
]

_TITLE_TERMS: dict[ProfessionGroup, tuple[str, ...]] = {
    ProfessionGroup.EDUCATION: (
        "teacher", "principal", "superintendent", "school administrator", "school board member",
        "professor", "college instructor", "dean",
    ),
    ProfessionGroup.NURSING: ("nurse", "nurse practitioner", "nursing director", "charge nurse"),
    ProfessionGroup.PHYSICIAN: ("physician", "doctor", "medical director", "practice partner"),
    ProfessionGroup.FIRE_SERVICE: ("firefighter", "fire captain", "fire chief", "battalion chief"),
    ProfessionGroup.PUBLIC_EMPLOYEE: (
        "government employee", "public employee", "city employee", "county employee", "state employee",
    ),
    ProfessionGroup.BUSINESS_OWNER: ("business owner", "small business owner", "founder and owner"),
}

_GENERIC_TERMS: dict[ProfessionGroup, tuple[str, ...]] = {
    ProfessionGroup.EDUCATION: ("school employee", "school staff", "school district", "university staff"),
    ProfessionGroup.NURSING: ("hospital staff", "healthcare worker", "nursing staff"),
    ProfessionGroup.PHYSICIAN: ("medical staff", "clinic staff", "medical practice"),
    ProfessionGroup.FIRE_SERVICE: ("fire department staff", "fire station"),
    ProfessionGroup.PUBLIC_EMPLOYEE: ("government staff", "public agency", "city hall"),
    ProfessionGroup.BUSINESS_OWNER: ("local business", "family-owned business"),
}

_ORG_SUFFIXES = (
    "Unified School District", "School District", "High School", "Elementary School", "Middle School",
    "Community College", "University", "College",
    "Medical Center", "Health System", "Hospital", "Clinic", "Medical Group",
    "Fire Department", "Fire District",
    "Police Department", "County", "Department",
)
_ORG_PATTERN = re.compile(
    r"([A-Z][A-Za-z.&'’ -]{2,40}?(?:" + "|".join(_ORG_SUFFIXES) + r"))"
)
_NAME_PATTERN = re.compile(r"\b([A-Z][a-z]+(?:\s[A-Z]\.)?\s[A-Z][a-z]+)\b")

# BeHive's claims carry no publication-date field at all (see behive/client.py
# get_report docstring) — the only date signal available is whatever the
# claim text itself mentions, so it's extracted here rather than left null.
_MONTHS = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
}
_MONTH_NAMES = "|".join(_MONTHS)
_FULL_DATE_PATTERN = re.compile(rf"\b({_MONTH_NAMES})\s+(\d{{1,2}}),?\s+(\d{{4}})\b", re.IGNORECASE)
_MONTH_YEAR_PATTERN = re.compile(rf"\b({_MONTH_NAMES})\s+(\d{{4}})\b", re.IGNORECASE)
_YEAR_PATTERN = re.compile(r"\b(20\d{2})\b")


def _extract_event_date(text: str) -> date | None:
    if m := _FULL_DATE_PATTERN.search(text):
        month, day, year = _MONTHS[m.group(1).lower()], int(m.group(2)), int(m.group(3))
        try:
            return date(year, month, day)
        except ValueError:
            pass
    if m := _MONTH_YEAR_PATTERN.search(text):
        return date(int(m.group(2)), _MONTHS[m.group(1).lower()], 1)
    if m := _YEAR_PATTERN.search(text):
        return date(int(m.group(1)), 1, 1)
    return None


def _match_signal_type(text_lower: str) -> SignalType | None:
    for signal_type, keywords in _SIGNAL_TYPE_KEYWORDS:
        if any(kw in text_lower for kw in keywords):
            return signal_type
    return None


def _match_profession(
    text_lower: str, group: ProfessionGroup
) -> tuple[ProfessionMatchConfidence | None, str | None]:
    title_terms = _TITLE_TERMS.get(group, ())
    hits = [t for t in title_terms if t in text_lower]
    if len(hits) >= 2:
        return ProfessionMatchConfidence.HIGH, hits[0]
    if len(hits) == 1:
        return ProfessionMatchConfidence.MODERATE, hits[0]
    if any(t in text_lower for t in _GENERIC_TERMS.get(group, ())):
        return ProfessionMatchConfidence.LOW, None
    return None, None


def _match_employment_sector(text_lower: str, group: ProfessionGroup) -> EmploymentSector:
    if group is ProfessionGroup.BUSINESS_OWNER:
        return EmploymentSector.BUSINESS_OWNER
    if "private practice" in text_lower or "self-employed" in text_lower:
        return EmploymentSector.SELF_EMPLOYED
    if any(t in text_lower for t in ("private school", "private company", "private hospital", "private practice")):
        return EmploymentSector.PRIVATE
    if any(
        t in text_lower
        for t in (
            "public school", "school district", "county", "city of", "state agency",
            "fire department", "public hospital", "government agency",
        )
    ):
        return EmploymentSector.PUBLIC
    return EmploymentSector.UNKNOWN


def classify_claim(
    claim: RawClaim,
    *,
    campaign_id: UUID,
    mission_id: UUID,
    profession_group: ProfessionGroup,
    state_code: str,
    campaign_segment: str,
) -> SignalDraft | None:
    """Returns None when the claim carries no recognizable signal at all —
    callers should treat that as "not a candidate", not run it through
    acceptance (there's nothing there to reject with a specific reason).
    """
    text_lower = claim.text.lower()

    signal_type = _match_signal_type(text_lower)
    if signal_type is None:
        return None

    confidence, matched_title = _match_profession(text_lower, profession_group)
    org_match = _ORG_PATTERN.search(claim.text)
    name_match = _NAME_PATTERN.search(claim.text)

    return SignalDraft(
        campaign_id=campaign_id,
        mission_id=mission_id,
        claim_text=claim.text,
        source_url=claim.source_url,
        raw_claim=claim.raw,
        target_profession=matched_title,
        target_profession_group=profession_group,
        employment_sector=_match_employment_sector(text_lower, profession_group),
        organization_signal=org_match.group(1) if org_match else None,
        individual_signal=name_match.group(1) if name_match else None,
        campaign_segment=campaign_segment,
        profession_match_confidence=confidence,
        profession_source_url=claim.source_url if confidence is not None else None,
        signal_type=signal_type,
        state=state_code,
        event_date=claim.published_at or _extract_event_date(claim.text),
    )
