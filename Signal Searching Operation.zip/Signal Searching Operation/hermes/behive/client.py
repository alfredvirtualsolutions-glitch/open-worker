"""Thin async wrapper around BeHive's REST API.

Hermes talks to BeHive over plain HTTP, not MCP — BeHive is a separate,
already-running service (`behive serve` / `docker compose up -d` in the
`behive` folder), never imported or vendored here.

Endpoint shapes here follow ../../behive/src/behive/server.py directly, not
../../behive/README.md — the README documents a more aspirational API
(`job_id`, a `/research/{id}/report` path, an `/events` SSE stream) that
doesn't match what the running FastAPI app actually implements as of this
writing: the response key is `mission_id`, the completed-mission endpoint is
`GET /research/{mission_id}` (no `/report` suffix), there's no SSE route, and
cross-mission search is `GET /claims/search`, not `GET /search`. Re-check
server.py if BeHive's API changes.
"""

from __future__ import annotations

import os
from typing import Any

import httpx


class BeHiveError(RuntimeError):
    """Raised for any non-2xx response or transport failure talking to BeHive."""


class BeHiveClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = (base_url or os.environ["BEHIVE_BASE_URL"]).rstrip("/")
        self.api_key = api_key if api_key is not None else os.environ.get("BEHIVE_API_KEY") or None
        resolved_timeout = timeout if timeout is not None else float(os.environ.get("BEHIVE_HTTP_TIMEOUT", 30))
        headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        self._client = client or httpx.AsyncClient(
            base_url=self.base_url, timeout=resolved_timeout, headers=headers
        )

    async def __aenter__(self) -> "BeHiveClient":
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict:
        try:
            response = await self._client.request(method, path, **kwargs)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise BeHiveError(
                f"{method} {path} -> {exc.response.status_code}: {exc.response.text[:500]}"
            ) from exc
        except httpx.HTTPError as exc:
            raise BeHiveError(f"{method} {path} failed: {exc}") from exc
        return response.json()

    async def start_research(self, query: str, depth: int = 3, scale: int | None = None) -> str:
        """POST /research — returns BeHive's mission_id."""
        payload: dict[str, Any] = {"query": query, "depth": depth}
        if scale is not None:
            payload["scale"] = scale
        body = await self._request("POST", "/research", json=payload)
        return body["mission_id"]

    async def mission_status(self, mission_id: str) -> dict:
        """GET /research/{id}/status — {mission_id, status, phase}."""
        return await self._request("GET", f"/research/{mission_id}/status")

    async def get_report(self, mission_id: str) -> dict:
        """GET /research/{id} — {mission_id, topic, status, report, claims, metrics}
        for a completed mission. Each claim: {text, confidence, quality_score,
        source_url, type} — note there is no publication-date field.
        """
        return await self._request("GET", f"/research/{mission_id}")

    async def search_knowledge(self, query: str, limit: int = 20) -> dict:
        """GET /claims/search — cross-mission claim search, used for cross-source
        verification. Returns {query, results, total}.
        """
        return await self._request("GET", "/claims/search", params={"q": query, "limit": limit})
