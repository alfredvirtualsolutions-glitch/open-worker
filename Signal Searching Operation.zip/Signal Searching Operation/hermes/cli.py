"""Command-line entry points documented in README.md `## Running`.

Every command is a short-lived process: load .env, do one thing against
Postgres and/or BeHive, close the pool, exit. `run`/`run-all` and
`process-missions` are meant to be triggered by separate cron entries (see
README) rather than run as a long-lived daemon.

This Neon database is shared across 4 LEADFORCE clients (see
hermes/config/clients.py), each with a fully separate set of tables.
`process-missions` and `review-queue` loop over every known client since
in-flight missions/pending reviews can exist for any of them at once;
`run`/`run-all` operate on one client at a time (lane_slug already encodes
which client it belongs to).
"""

from __future__ import annotations

import asyncio

import asyncpg
import click
import httpx
from dotenv import load_dotenv

from hermes.behive import BeHiveClient, BeHiveError
from hermes.config import CLIENTS, campaign_from_record, load_campaigns
from hermes.db import close_pool, get_pool, init_schema
from hermes.db import repo
from hermes.domain.enums import ProfessionGroup, SourceCategory, VerificationStatus
from hermes.domain.models import RawClaim
from hermes.pipeline import classify_claim, evaluate_acceptance, score_signal
from hermes.query import build_queries

load_dotenv()


def _client_slug_from_lane_slug(lane_slug: str) -> str:
    for slug in CLIENTS:
        if lane_slug.startswith(f"{slug}-"):
            return slug
    raise click.ClickException(
        f"lane_slug {lane_slug!r} doesn't start with any known client slug ({sorted(CLIENTS)})"
    )


async def _source_still_live(url: str) -> bool:
    if not url:
        return False
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
            resp = await client.head(url)
            if resp.status_code == 405:
                resp = await client.get(url)
            return resp.status_code < 400
    except httpx.HTTPError:
        return False


async def _submit_campaign(
    pool: asyncpg.Pool, behive: BeHiveClient, client_slug: str, campaign_row: asyncpg.Record
) -> int:
    campaign = campaign_from_record(campaign_row, client_slug)
    queries = build_queries(campaign)
    for query_text in queries:
        try:
            mission_id = await behive.start_research(query_text, depth=campaign.depth)
        except BeHiveError as exc:
            await repo.log_search_failure(
                pool, client_slug, campaign_row["id"], None, campaign.source_category.value, "error", str(exc)
            )
            click.echo(f"[{campaign.lane_slug}] FAILED to submit: {exc}", err=True)
            continue
        await repo.create_mission(pool, client_slug, campaign_row["id"], mission_id, query_text, campaign.depth)
        click.echo(f"[{campaign.lane_slug}] submitted {mission_id}: {query_text}")
    return len(queries)


async def _ingest_completed_mission(
    pool: asyncpg.Pool, behive: BeHiveClient, client_slug: str, mission_row: asyncpg.Record
) -> None:
    campaign_row = await repo.get_campaign_by_id(pool, client_slug, mission_row["campaign_id"])
    profession_group = ProfessionGroup(campaign_row["profession_group"])
    source_category = SourceCategory(campaign_row["source_category"])

    report = await behive.get_report(mission_row["mission_id"])
    verified_count = 0

    for raw in report.get("claims", []):
        claim = RawClaim(
            text=raw.get("text", ""),
            source_url=raw.get("source_url", ""),
            quality=raw.get("quality_score"),
            raw=raw,
        )
        draft = classify_claim(
            claim,
            campaign_id=mission_row["campaign_id"],
            mission_id=mission_row["id"],
            profession_group=profession_group,
            state_code=campaign_row["state_code"],
            campaign_segment=campaign_row["lane_slug"],
        )
        if draft is None:
            continue

        score_signal(draft, source_category)
        source_still_live = await _source_still_live(draft.source_url)
        evaluate_acceptance(draft, score_threshold=campaign_row["score_threshold"], source_still_live=source_still_live)

        signal_id = await repo.insert_signal(pool, client_slug, draft)
        if draft.verification_status == VerificationStatus.VERIFIED_SIGNAL:
            await repo.enqueue_for_review(pool, client_slug, signal_id)
            verified_count += 1

    await repo.complete_mission(
        pool,
        client_slug,
        mission_row["id"],
        report.get("report", ""),
        {k: v for k, v in report.items() if k not in ("claims", "report")},
    )
    click.echo(
        f"[{client_slug}/{campaign_row['lane_slug']}] {mission_row['mission_id']}: "
        f"{len(report.get('claims', []))} claim(s), {verified_count} verified signal(s)"
    )


@click.group()
def cli() -> None:
    pass


@cli.group(name="db")
def db_group() -> None:
    pass


@db_group.command(name="init")
def db_init() -> None:
    """Applies schema.sql — all 4 clients' tables (idempotent, safe to re-run)."""

    async def _run() -> None:
        pool = await get_pool()
        await init_schema(pool)
        await close_pool()

    asyncio.run(_run())
    click.echo("Schema applied.")


@cli.command(name="seed-campaigns")
def seed_campaigns() -> None:
    """Loads hermes/config/campaigns.yaml and upserts each row into its client's campaigns table."""
    campaigns = load_campaigns()

    async def _run() -> None:
        pool = await get_pool()
        await repo.upsert_campaigns(pool, campaigns)
        await close_pool()

    asyncio.run(_run())
    by_client: dict[str, int] = {}
    for c in campaigns:
        by_client[c.client_slug] = by_client.get(c.client_slug, 0) + 1
    click.echo(f"Seeded {len(campaigns)} campaign(s): " + ", ".join(f"{k}={v}" for k, v in by_client.items()))


@cli.command(name="run")
@click.option("--campaign", "lane_slug", required=True, help="lane_slug from campaigns.yaml")
def run(lane_slug: str) -> None:
    """Submits research queries for one campaign lane (client is inferred from the lane_slug prefix)."""
    client_slug = _client_slug_from_lane_slug(lane_slug)

    async def _run() -> None:
        pool = await get_pool()
        campaign_row = await repo.get_campaign_by_slug(pool, client_slug, lane_slug)
        if campaign_row is None:
            click.echo(f"No campaign found for lane_slug={lane_slug!r} in client {client_slug!r}", err=True)
            raise SystemExit(1)
        async with BeHiveClient() as behive:
            await _submit_campaign(pool, behive, client_slug, campaign_row)
        await close_pool()

    asyncio.run(_run())


@cli.command(name="run-all")
@click.option("--client", "client_slug", required=True, type=click.Choice(sorted(CLIENTS)), help="client slug")
@click.option("--state", "state_code", default=None, help="optional two-letter state filter, e.g. CA")
def run_all(client_slug: str, state_code: str | None) -> None:
    """Submits research queries for every active campaign lane for one client (optionally filtered by state)."""

    async def _run() -> None:
        pool = await get_pool()
        rows = (
            await repo.get_active_campaigns_by_state(pool, client_slug, state_code)
            if state_code
            else await repo.get_active_campaigns(pool, client_slug)
        )
        if not rows:
            scope = f"state={state_code.upper()!r}" if state_code else "any state"
            click.echo(f"No active campaigns for client={client_slug!r}, {scope}")
        async with BeHiveClient() as behive:
            for campaign_row in rows:
                await _submit_campaign(pool, behive, client_slug, campaign_row)
        await close_pool()

    asyncio.run(_run())


@cli.command(name="process-missions")
def process_missions() -> None:
    """Polls in-flight BeHive missions across every client; classifies/scores/persists completed ones."""

    async def _run() -> None:
        pool = await get_pool()
        async with BeHiveClient() as behive:
            for client_slug in CLIENTS:
                in_flight = await repo.get_in_flight_missions(pool, client_slug)
                if not in_flight:
                    continue
                for mission_row in in_flight:
                    try:
                        status = await behive.mission_status(mission_row["mission_id"])
                    except BeHiveError as exc:
                        click.echo(f"[{client_slug}] status check failed for {mission_row['mission_id']}: {exc}", err=True)
                        continue

                    mission_status = status.get("status", "running")
                    if mission_status in ("queued", "running"):
                        await repo.mark_mission_polled(
                            pool, client_slug, mission_row["id"], mission_status, status.get("phase")
                        )
                        continue
                    if mission_status in ("failed", "timed_out"):
                        await repo.fail_mission(
                            pool, client_slug, mission_row["id"], f"BeHive reported status={mission_status}"
                        )
                        continue

                    try:
                        await _ingest_completed_mission(pool, behive, client_slug, mission_row)
                    except BeHiveError as exc:
                        await repo.fail_mission(pool, client_slug, mission_row["id"], str(exc))
                        click.echo(f"[{client_slug}] failed to fetch report for {mission_row['mission_id']}: {exc}", err=True)
        await close_pool()

    asyncio.run(_run())


@cli.command(name="review-queue")
@click.option(
    "--client", "client_slug", default=None, type=click.Choice(sorted(CLIENTS)), help="limit to one client"
)
def review_queue(client_slug: str | None) -> None:
    """Lists signals awaiting a human decision, across all clients by default."""

    async def _run() -> None:
        pool = await get_pool()
        slugs = [client_slug] if client_slug else list(CLIENTS)
        found_any = False
        for slug in slugs:
            rows = await repo.list_pending_review(pool, slug)
            for row in rows:
                found_any = True
                click.echo(
                    f"[{slug}/{row['campaign_segment']}] {row['signal_type']} — "
                    f"{row['target_profession']} ({row['state']}) "
                    f"score={row['total_score']} :: {row['source_url']}"
                )
        if not found_any:
            click.echo("No signals awaiting review.")
        await close_pool()

    asyncio.run(_run())


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
