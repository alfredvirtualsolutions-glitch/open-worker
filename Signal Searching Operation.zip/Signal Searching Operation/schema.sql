-- juan-os-hermes schema
-- Applied once via `python -m hermes db init` against DATABASE_URL (Neon or any Postgres).
--
-- Design note: enums are enforced via CHECK constraints (not Postgres ENUM types) so that
-- adding a new value later is an ALTER TABLE ... DROP/ADD CONSTRAINT, not a migration of an
-- enum type across every dependent object.
--
-- Naming: this Neon database is shared across 4 LEADFORCE clients. Each client gets a
-- FULLY SEPARATE set of the 8 tables below -- hermes_{client_slug}_{table} -- so one
-- client's data, queries, and any future schema drift can never touch another's. See
-- hermes/config/clients.py for the client registry. Adding a 5th client means copying
-- one of the per-client blocks below with the new slug, not editing existing blocks.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =============================================================================
-- Client: ryancahill
-- =============================================================================

-- hermes_ryancahill_campaigns: one row per search lane. Never mix professions in one lane.
CREATE TABLE IF NOT EXISTS hermes_ryancahill_campaigns (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    lane_slug           text NOT NULL UNIQUE,               -- e.g. ryancahill-ca-education-official
    state_code          char(2) NOT NULL,
    profession_group    text NOT NULL CHECK (profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    source_category     text NOT NULL CHECK (source_category IN
        ('official_sources', 'news_and_press', 'linkedin_public', 'facebook_public', 'x_and_threads',
         'instagram_and_youtube', 'job_boards', 'official_career_pages', 'business_transition_sources',
         'public_forum_trends')),
    score_threshold     int NOT NULL DEFAULT 50,
    depth               int NOT NULL DEFAULT 2 CHECK (depth BETWEEN 1 AND 5),
    active              boolean NOT NULL DEFAULT true,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now()
);

-- hermes_ryancahill_behive_missions: tracks one BeHive research submission and its lifecycle.
CREATE TABLE IF NOT EXISTS hermes_ryancahill_behive_missions (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id         uuid NOT NULL REFERENCES hermes_ryancahill_campaigns(id),
    mission_id          text NOT NULL UNIQUE,                -- BeHive's own id, e.g. hive_<ts>_<hash>
    query_text          text NOT NULL,
    depth               int NOT NULL,
    status              text NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'running', 'completed', 'failed', 'timed_out')),
    phase               text,
    submitted_at        timestamptz NOT NULL DEFAULT now(),
    last_polled_at      timestamptz,
    completed_at        timestamptz,
    poll_attempts       int NOT NULL DEFAULT 0,
    error_message       text,
    raw_report          text,
    metrics             jsonb
);
CREATE INDEX IF NOT EXISTS idx_ryancahill_behive_missions_status ON hermes_ryancahill_behive_missions(status);

-- hermes_ryancahill_signals: the core scored record. A row here is NOT a lead until
-- verification_status = 'verified_signal' (see pipeline/acceptance.py).
CREATE TABLE IF NOT EXISTS hermes_ryancahill_signals (
    id                          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id                 uuid NOT NULL REFERENCES hermes_ryancahill_campaigns(id),
    mission_id                  uuid NOT NULL REFERENCES hermes_ryancahill_behive_missions(id),

    target_profession           text,
    target_profession_group     text CHECK (target_profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    employment_sector           text CHECK (employment_sector IN
        ('public', 'private', 'nonprofit', 'self_employed', 'business_owner', 'unknown')),
    employer_type                text,
    retirement_system            text,
    account_type_relevance       text,
    organization_signal          text,
    individual_signal            text,
    campaign_segment             text,                       -- denormalized lane_slug, for easy filtering
    profession_match_confidence  text CHECK (profession_match_confidence IN ('High', 'Moderate', 'Low')),
    profession_source_url        text,

    signal_type                  text,                        -- fixed vocabulary; validated in classifier.py

    social_source_score          int NOT NULL DEFAULT 0,
    social_evidence_score        int NOT NULL DEFAULT 0,
    jobsite_evidence_score       int NOT NULL DEFAULT 0,
    cross_source_score           int NOT NULL DEFAULT 0,
    total_score                  int NOT NULL DEFAULT 0,

    verification_status          text NOT NULL DEFAULT 'pending' CHECK (verification_status IN
        ('pending', 'verified_signal', 'rejected', 'archived_research')),
    rejection_reason_code        text,

    state                        char(2),
    source_url                   text,
    event_date                   date,
    claim_text                   text,
    raw_claim                    jsonb,

    created_at                   timestamptz NOT NULL DEFAULT now(),
    updated_at                   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ryancahill_signals_group_state ON hermes_ryancahill_signals(target_profession_group, state);
CREATE INDEX IF NOT EXISTS idx_ryancahill_signals_status ON hermes_ryancahill_signals(verification_status);

-- hermes_ryancahill_social_posts / hermes_ryancahill_job_postings: source-specific evidence backing a signal.
-- Populated starting in later phases (social + job-board lanes).
CREATE TABLE IF NOT EXISTS hermes_ryancahill_social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id        uuid NOT NULL REFERENCES hermes_ryancahill_signals(id),
    platform         text CHECK (platform IN
        ('linkedin', 'facebook', 'x', 'threads', 'instagram', 'youtube', 'other')),
    author_name      text,
    author_title     text,
    employer_name    text,
    post_url         text,
    post_text        text,
    posted_at        date,
    source_score     int,
    evidence_score   int,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hermes_ryancahill_job_postings (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id             uuid NOT NULL REFERENCES hermes_ryancahill_signals(id),
    posting_url           text,
    board                 text,
    title                 text,
    organization_name     text,
    posted_date           date,
    evidence_score        int,
    relation_to_signal    text CHECK (relation_to_signal IN
        ('vacancy_due_to_retirement', 'seeking_successor', 'supports_transition',
         'general_org_change', 'no_connection')),
    created_at            timestamptz NOT NULL DEFAULT now()
);

-- hermes_ryancahill_cross_source_verifications: corroborating evidence found via claims/search.
CREATE TABLE IF NOT EXISTS hermes_ryancahill_cross_source_verifications (
    id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id               uuid NOT NULL REFERENCES hermes_ryancahill_signals(id),
    primary_source_url      text,
    verifying_source_url    text,
    verifying_source_type   text CHECK (verifying_source_type IN
        ('official', 'reputable_secondary', 'partial', 'none')),
    verification_score      int,
    verified_at             timestamptz NOT NULL DEFAULT now(),
    notes                   text
);

-- hermes_ryancahill_platform_search_failures: failures are logged, never silently dropped.
CREATE TABLE IF NOT EXISTS hermes_ryancahill_platform_search_failures (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id     uuid REFERENCES hermes_ryancahill_campaigns(id),
    mission_id      uuid REFERENCES hermes_ryancahill_behive_missions(id),
    source_category text,
    failure_type    text CHECK (failure_type IN ('timeout', 'rate_limited', 'no_results', 'error', 'blocked')),
    message         text,
    occurred_at     timestamptz NOT NULL DEFAULT now()
);

-- hermes_ryancahill_human_review_queue: the terminal automated step. This system stops here --
-- no outreach table exists, and nothing writes to one.
CREATE TABLE IF NOT EXISTS hermes_ryancahill_human_review_queue (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id      uuid NOT NULL UNIQUE REFERENCES hermes_ryancahill_signals(id),
    queued_at      timestamptz NOT NULL DEFAULT now(),
    status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'actioned')),
    reviewed_by    text,
    reviewed_at    timestamptz,
    reviewer_notes text
);

CREATE OR REPLACE VIEW hermes_ryancahill_v_human_review_queue AS
    SELECT q.id AS queue_id, q.status AS queue_status, q.queued_at, q.reviewed_by, q.reviewed_at,
           q.reviewer_notes, s.*
    FROM hermes_ryancahill_human_review_queue q
    JOIN hermes_ryancahill_signals s ON s.id = q.signal_id
    WHERE s.verification_status = 'verified_signal';

-- =============================================================================
-- Client: dontowns
-- =============================================================================

-- hermes_dontowns_campaigns: one row per search lane. Never mix professions in one lane.
CREATE TABLE IF NOT EXISTS hermes_dontowns_campaigns (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    lane_slug           text NOT NULL UNIQUE,               -- e.g. dontowns-ca-education-official
    state_code          char(2) NOT NULL,
    profession_group    text NOT NULL CHECK (profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    source_category     text NOT NULL CHECK (source_category IN
        ('official_sources', 'news_and_press', 'linkedin_public', 'facebook_public', 'x_and_threads',
         'instagram_and_youtube', 'job_boards', 'official_career_pages', 'business_transition_sources',
         'public_forum_trends')),
    score_threshold     int NOT NULL DEFAULT 50,
    depth               int NOT NULL DEFAULT 2 CHECK (depth BETWEEN 1 AND 5),
    active              boolean NOT NULL DEFAULT true,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now()
);

-- hermes_dontowns_behive_missions: tracks one BeHive research submission and its lifecycle.
CREATE TABLE IF NOT EXISTS hermes_dontowns_behive_missions (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id         uuid NOT NULL REFERENCES hermes_dontowns_campaigns(id),
    mission_id          text NOT NULL UNIQUE,                -- BeHive's own id, e.g. hive_<ts>_<hash>
    query_text          text NOT NULL,
    depth               int NOT NULL,
    status              text NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'running', 'completed', 'failed', 'timed_out')),
    phase               text,
    submitted_at        timestamptz NOT NULL DEFAULT now(),
    last_polled_at      timestamptz,
    completed_at        timestamptz,
    poll_attempts       int NOT NULL DEFAULT 0,
    error_message       text,
    raw_report          text,
    metrics             jsonb
);
CREATE INDEX IF NOT EXISTS idx_dontowns_behive_missions_status ON hermes_dontowns_behive_missions(status);

-- hermes_dontowns_signals: the core scored record. A row here is NOT a lead until
-- verification_status = 'verified_signal' (see pipeline/acceptance.py).
CREATE TABLE IF NOT EXISTS hermes_dontowns_signals (
    id                          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id                 uuid NOT NULL REFERENCES hermes_dontowns_campaigns(id),
    mission_id                  uuid NOT NULL REFERENCES hermes_dontowns_behive_missions(id),

    target_profession           text,
    target_profession_group     text CHECK (target_profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    employment_sector           text CHECK (employment_sector IN
        ('public', 'private', 'nonprofit', 'self_employed', 'business_owner', 'unknown')),
    employer_type                text,
    retirement_system            text,
    account_type_relevance       text,
    organization_signal          text,
    individual_signal            text,
    campaign_segment             text,                       -- denormalized lane_slug, for easy filtering
    profession_match_confidence  text CHECK (profession_match_confidence IN ('High', 'Moderate', 'Low')),
    profession_source_url        text,

    signal_type                  text,                        -- fixed vocabulary; validated in classifier.py

    social_source_score          int NOT NULL DEFAULT 0,
    social_evidence_score        int NOT NULL DEFAULT 0,
    jobsite_evidence_score       int NOT NULL DEFAULT 0,
    cross_source_score           int NOT NULL DEFAULT 0,
    total_score                  int NOT NULL DEFAULT 0,

    verification_status          text NOT NULL DEFAULT 'pending' CHECK (verification_status IN
        ('pending', 'verified_signal', 'rejected', 'archived_research')),
    rejection_reason_code        text,

    state                        char(2),
    source_url                   text,
    event_date                   date,
    claim_text                   text,
    raw_claim                    jsonb,

    created_at                   timestamptz NOT NULL DEFAULT now(),
    updated_at                   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_dontowns_signals_group_state ON hermes_dontowns_signals(target_profession_group, state);
CREATE INDEX IF NOT EXISTS idx_dontowns_signals_status ON hermes_dontowns_signals(verification_status);

-- hermes_dontowns_social_posts / hermes_dontowns_job_postings: source-specific evidence backing a signal.
-- Populated starting in later phases (social + job-board lanes).
CREATE TABLE IF NOT EXISTS hermes_dontowns_social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id        uuid NOT NULL REFERENCES hermes_dontowns_signals(id),
    platform         text CHECK (platform IN
        ('linkedin', 'facebook', 'x', 'threads', 'instagram', 'youtube', 'other')),
    author_name      text,
    author_title     text,
    employer_name    text,
    post_url         text,
    post_text        text,
    posted_at        date,
    source_score     int,
    evidence_score   int,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hermes_dontowns_job_postings (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id             uuid NOT NULL REFERENCES hermes_dontowns_signals(id),
    posting_url           text,
    board                 text,
    title                 text,
    organization_name     text,
    posted_date           date,
    evidence_score        int,
    relation_to_signal    text CHECK (relation_to_signal IN
        ('vacancy_due_to_retirement', 'seeking_successor', 'supports_transition',
         'general_org_change', 'no_connection')),
    created_at            timestamptz NOT NULL DEFAULT now()
);

-- hermes_dontowns_cross_source_verifications: corroborating evidence found via claims/search.
CREATE TABLE IF NOT EXISTS hermes_dontowns_cross_source_verifications (
    id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id               uuid NOT NULL REFERENCES hermes_dontowns_signals(id),
    primary_source_url      text,
    verifying_source_url    text,
    verifying_source_type   text CHECK (verifying_source_type IN
        ('official', 'reputable_secondary', 'partial', 'none')),
    verification_score      int,
    verified_at             timestamptz NOT NULL DEFAULT now(),
    notes                   text
);

-- hermes_dontowns_platform_search_failures: failures are logged, never silently dropped.
CREATE TABLE IF NOT EXISTS hermes_dontowns_platform_search_failures (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id     uuid REFERENCES hermes_dontowns_campaigns(id),
    mission_id      uuid REFERENCES hermes_dontowns_behive_missions(id),
    source_category text,
    failure_type    text CHECK (failure_type IN ('timeout', 'rate_limited', 'no_results', 'error', 'blocked')),
    message         text,
    occurred_at     timestamptz NOT NULL DEFAULT now()
);

-- hermes_dontowns_human_review_queue: the terminal automated step. This system stops here --
-- no outreach table exists, and nothing writes to one.
CREATE TABLE IF NOT EXISTS hermes_dontowns_human_review_queue (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id      uuid NOT NULL UNIQUE REFERENCES hermes_dontowns_signals(id),
    queued_at      timestamptz NOT NULL DEFAULT now(),
    status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'actioned')),
    reviewed_by    text,
    reviewed_at    timestamptz,
    reviewer_notes text
);

CREATE OR REPLACE VIEW hermes_dontowns_v_human_review_queue AS
    SELECT q.id AS queue_id, q.status AS queue_status, q.queued_at, q.reviewed_by, q.reviewed_at,
           q.reviewer_notes, s.*
    FROM hermes_dontowns_human_review_queue q
    JOIN hermes_dontowns_signals s ON s.id = q.signal_id
    WHERE s.verification_status = 'verified_signal';

-- =============================================================================
-- Client: benjaminpersyn
-- =============================================================================

-- hermes_benjaminpersyn_campaigns: one row per search lane. Never mix professions in one lane.
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_campaigns (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    lane_slug           text NOT NULL UNIQUE,               -- e.g. benjaminpersyn-ca-education-official
    state_code          char(2) NOT NULL,
    profession_group    text NOT NULL CHECK (profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    source_category     text NOT NULL CHECK (source_category IN
        ('official_sources', 'news_and_press', 'linkedin_public', 'facebook_public', 'x_and_threads',
         'instagram_and_youtube', 'job_boards', 'official_career_pages', 'business_transition_sources',
         'public_forum_trends')),
    score_threshold     int NOT NULL DEFAULT 50,
    depth               int NOT NULL DEFAULT 2 CHECK (depth BETWEEN 1 AND 5),
    active              boolean NOT NULL DEFAULT true,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now()
);

-- hermes_benjaminpersyn_behive_missions: tracks one BeHive research submission and its lifecycle.
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_behive_missions (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id         uuid NOT NULL REFERENCES hermes_benjaminpersyn_campaigns(id),
    mission_id          text NOT NULL UNIQUE,                -- BeHive's own id, e.g. hive_<ts>_<hash>
    query_text          text NOT NULL,
    depth               int NOT NULL,
    status              text NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'running', 'completed', 'failed', 'timed_out')),
    phase               text,
    submitted_at        timestamptz NOT NULL DEFAULT now(),
    last_polled_at      timestamptz,
    completed_at        timestamptz,
    poll_attempts       int NOT NULL DEFAULT 0,
    error_message       text,
    raw_report          text,
    metrics             jsonb
);
CREATE INDEX IF NOT EXISTS idx_benjaminpersyn_behive_missions_status ON hermes_benjaminpersyn_behive_missions(status);

-- hermes_benjaminpersyn_signals: the core scored record. A row here is NOT a lead until
-- verification_status = 'verified_signal' (see pipeline/acceptance.py).
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_signals (
    id                          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id                 uuid NOT NULL REFERENCES hermes_benjaminpersyn_campaigns(id),
    mission_id                  uuid NOT NULL REFERENCES hermes_benjaminpersyn_behive_missions(id),

    target_profession           text,
    target_profession_group     text CHECK (target_profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    employment_sector           text CHECK (employment_sector IN
        ('public', 'private', 'nonprofit', 'self_employed', 'business_owner', 'unknown')),
    employer_type                text,
    retirement_system            text,
    account_type_relevance       text,
    organization_signal          text,
    individual_signal            text,
    campaign_segment             text,                       -- denormalized lane_slug, for easy filtering
    profession_match_confidence  text CHECK (profession_match_confidence IN ('High', 'Moderate', 'Low')),
    profession_source_url        text,

    signal_type                  text,                        -- fixed vocabulary; validated in classifier.py

    social_source_score          int NOT NULL DEFAULT 0,
    social_evidence_score        int NOT NULL DEFAULT 0,
    jobsite_evidence_score       int NOT NULL DEFAULT 0,
    cross_source_score           int NOT NULL DEFAULT 0,
    total_score                  int NOT NULL DEFAULT 0,

    verification_status          text NOT NULL DEFAULT 'pending' CHECK (verification_status IN
        ('pending', 'verified_signal', 'rejected', 'archived_research')),
    rejection_reason_code        text,

    state                        char(2),
    source_url                   text,
    event_date                   date,
    claim_text                   text,
    raw_claim                    jsonb,

    created_at                   timestamptz NOT NULL DEFAULT now(),
    updated_at                   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_benjaminpersyn_signals_group_state ON hermes_benjaminpersyn_signals(target_profession_group, state);
CREATE INDEX IF NOT EXISTS idx_benjaminpersyn_signals_status ON hermes_benjaminpersyn_signals(verification_status);

-- hermes_benjaminpersyn_social_posts / hermes_benjaminpersyn_job_postings: source-specific evidence backing a signal.
-- Populated starting in later phases (social + job-board lanes).
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id        uuid NOT NULL REFERENCES hermes_benjaminpersyn_signals(id),
    platform         text CHECK (platform IN
        ('linkedin', 'facebook', 'x', 'threads', 'instagram', 'youtube', 'other')),
    author_name      text,
    author_title     text,
    employer_name    text,
    post_url         text,
    post_text        text,
    posted_at        date,
    source_score     int,
    evidence_score   int,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_job_postings (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id             uuid NOT NULL REFERENCES hermes_benjaminpersyn_signals(id),
    posting_url           text,
    board                 text,
    title                 text,
    organization_name     text,
    posted_date           date,
    evidence_score        int,
    relation_to_signal    text CHECK (relation_to_signal IN
        ('vacancy_due_to_retirement', 'seeking_successor', 'supports_transition',
         'general_org_change', 'no_connection')),
    created_at            timestamptz NOT NULL DEFAULT now()
);

-- hermes_benjaminpersyn_cross_source_verifications: corroborating evidence found via claims/search.
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_cross_source_verifications (
    id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id               uuid NOT NULL REFERENCES hermes_benjaminpersyn_signals(id),
    primary_source_url      text,
    verifying_source_url    text,
    verifying_source_type   text CHECK (verifying_source_type IN
        ('official', 'reputable_secondary', 'partial', 'none')),
    verification_score      int,
    verified_at             timestamptz NOT NULL DEFAULT now(),
    notes                   text
);

-- hermes_benjaminpersyn_platform_search_failures: failures are logged, never silently dropped.
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_platform_search_failures (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id     uuid REFERENCES hermes_benjaminpersyn_campaigns(id),
    mission_id      uuid REFERENCES hermes_benjaminpersyn_behive_missions(id),
    source_category text,
    failure_type    text CHECK (failure_type IN ('timeout', 'rate_limited', 'no_results', 'error', 'blocked')),
    message         text,
    occurred_at     timestamptz NOT NULL DEFAULT now()
);

-- hermes_benjaminpersyn_human_review_queue: the terminal automated step. This system stops here --
-- no outreach table exists, and nothing writes to one.
CREATE TABLE IF NOT EXISTS hermes_benjaminpersyn_human_review_queue (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id      uuid NOT NULL UNIQUE REFERENCES hermes_benjaminpersyn_signals(id),
    queued_at      timestamptz NOT NULL DEFAULT now(),
    status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'actioned')),
    reviewed_by    text,
    reviewed_at    timestamptz,
    reviewer_notes text
);

CREATE OR REPLACE VIEW hermes_benjaminpersyn_v_human_review_queue AS
    SELECT q.id AS queue_id, q.status AS queue_status, q.queued_at, q.reviewed_by, q.reviewed_at,
           q.reviewer_notes, s.*
    FROM hermes_benjaminpersyn_human_review_queue q
    JOIN hermes_benjaminpersyn_signals s ON s.id = q.signal_id
    WHERE s.verification_status = 'verified_signal';

-- =============================================================================
-- Client: juancabezas
-- =============================================================================

-- hermes_juancabezas_campaigns: one row per search lane. Never mix professions in one lane.
CREATE TABLE IF NOT EXISTS hermes_juancabezas_campaigns (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    lane_slug           text NOT NULL UNIQUE,               -- e.g. juancabezas-ca-education-official
    state_code          char(2) NOT NULL,
    profession_group    text NOT NULL CHECK (profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    source_category     text NOT NULL CHECK (source_category IN
        ('official_sources', 'news_and_press', 'linkedin_public', 'facebook_public', 'x_and_threads',
         'instagram_and_youtube', 'job_boards', 'official_career_pages', 'business_transition_sources',
         'public_forum_trends')),
    score_threshold     int NOT NULL DEFAULT 50,
    depth               int NOT NULL DEFAULT 2 CHECK (depth BETWEEN 1 AND 5),
    active              boolean NOT NULL DEFAULT true,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now()
);

-- hermes_juancabezas_behive_missions: tracks one BeHive research submission and its lifecycle.
CREATE TABLE IF NOT EXISTS hermes_juancabezas_behive_missions (
    id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id         uuid NOT NULL REFERENCES hermes_juancabezas_campaigns(id),
    mission_id          text NOT NULL UNIQUE,                -- BeHive's own id, e.g. hive_<ts>_<hash>
    query_text          text NOT NULL,
    depth               int NOT NULL,
    status              text NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'running', 'completed', 'failed', 'timed_out')),
    phase               text,
    submitted_at        timestamptz NOT NULL DEFAULT now(),
    last_polled_at      timestamptz,
    completed_at        timestamptz,
    poll_attempts       int NOT NULL DEFAULT 0,
    error_message       text,
    raw_report          text,
    metrics             jsonb
);
CREATE INDEX IF NOT EXISTS idx_juancabezas_behive_missions_status ON hermes_juancabezas_behive_missions(status);

-- hermes_juancabezas_signals: the core scored record. A row here is NOT a lead until
-- verification_status = 'verified_signal' (see pipeline/acceptance.py).
CREATE TABLE IF NOT EXISTS hermes_juancabezas_signals (
    id                          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id                 uuid NOT NULL REFERENCES hermes_juancabezas_campaigns(id),
    mission_id                  uuid NOT NULL REFERENCES hermes_juancabezas_behive_missions(id),

    target_profession           text,
    target_profession_group     text CHECK (target_profession_group IN
        ('education', 'nursing', 'physician', 'fire_service', 'public_employee', 'business_owner')),
    employment_sector           text CHECK (employment_sector IN
        ('public', 'private', 'nonprofit', 'self_employed', 'business_owner', 'unknown')),
    employer_type                text,
    retirement_system            text,
    account_type_relevance       text,
    organization_signal          text,
    individual_signal            text,
    campaign_segment             text,                       -- denormalized lane_slug, for easy filtering
    profession_match_confidence  text CHECK (profession_match_confidence IN ('High', 'Moderate', 'Low')),
    profession_source_url        text,

    signal_type                  text,                        -- fixed vocabulary; validated in classifier.py

    social_source_score          int NOT NULL DEFAULT 0,
    social_evidence_score        int NOT NULL DEFAULT 0,
    jobsite_evidence_score       int NOT NULL DEFAULT 0,
    cross_source_score           int NOT NULL DEFAULT 0,
    total_score                  int NOT NULL DEFAULT 0,

    verification_status          text NOT NULL DEFAULT 'pending' CHECK (verification_status IN
        ('pending', 'verified_signal', 'rejected', 'archived_research')),
    rejection_reason_code        text,

    state                        char(2),
    source_url                   text,
    event_date                   date,
    claim_text                   text,
    raw_claim                    jsonb,

    created_at                   timestamptz NOT NULL DEFAULT now(),
    updated_at                   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_juancabezas_signals_group_state ON hermes_juancabezas_signals(target_profession_group, state);
CREATE INDEX IF NOT EXISTS idx_juancabezas_signals_status ON hermes_juancabezas_signals(verification_status);

-- hermes_juancabezas_social_posts / hermes_juancabezas_job_postings: source-specific evidence backing a signal.
-- Populated starting in later phases (social + job-board lanes).
CREATE TABLE IF NOT EXISTS hermes_juancabezas_social_posts (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id        uuid NOT NULL REFERENCES hermes_juancabezas_signals(id),
    platform         text CHECK (platform IN
        ('linkedin', 'facebook', 'x', 'threads', 'instagram', 'youtube', 'other')),
    author_name      text,
    author_title     text,
    employer_name    text,
    post_url         text,
    post_text        text,
    posted_at        date,
    source_score     int,
    evidence_score   int,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS hermes_juancabezas_job_postings (
    id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id             uuid NOT NULL REFERENCES hermes_juancabezas_signals(id),
    posting_url           text,
    board                 text,
    title                 text,
    organization_name     text,
    posted_date           date,
    evidence_score        int,
    relation_to_signal    text CHECK (relation_to_signal IN
        ('vacancy_due_to_retirement', 'seeking_successor', 'supports_transition',
         'general_org_change', 'no_connection')),
    created_at            timestamptz NOT NULL DEFAULT now()
);

-- hermes_juancabezas_cross_source_verifications: corroborating evidence found via claims/search.
CREATE TABLE IF NOT EXISTS hermes_juancabezas_cross_source_verifications (
    id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id               uuid NOT NULL REFERENCES hermes_juancabezas_signals(id),
    primary_source_url      text,
    verifying_source_url    text,
    verifying_source_type   text CHECK (verifying_source_type IN
        ('official', 'reputable_secondary', 'partial', 'none')),
    verification_score      int,
    verified_at             timestamptz NOT NULL DEFAULT now(),
    notes                   text
);

-- hermes_juancabezas_platform_search_failures: failures are logged, never silently dropped.
CREATE TABLE IF NOT EXISTS hermes_juancabezas_platform_search_failures (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id     uuid REFERENCES hermes_juancabezas_campaigns(id),
    mission_id      uuid REFERENCES hermes_juancabezas_behive_missions(id),
    source_category text,
    failure_type    text CHECK (failure_type IN ('timeout', 'rate_limited', 'no_results', 'error', 'blocked')),
    message         text,
    occurred_at     timestamptz NOT NULL DEFAULT now()
);

-- hermes_juancabezas_human_review_queue: the terminal automated step. This system stops here --
-- no outreach table exists, and nothing writes to one.
CREATE TABLE IF NOT EXISTS hermes_juancabezas_human_review_queue (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    signal_id      uuid NOT NULL UNIQUE REFERENCES hermes_juancabezas_signals(id),
    queued_at      timestamptz NOT NULL DEFAULT now(),
    status         text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'actioned')),
    reviewed_by    text,
    reviewed_at    timestamptz,
    reviewer_notes text
);

CREATE OR REPLACE VIEW hermes_juancabezas_v_human_review_queue AS
    SELECT q.id AS queue_id, q.status AS queue_status, q.queued_at, q.reviewed_by, q.reviewed_at,
           q.reviewer_notes, s.*
    FROM hermes_juancabezas_human_review_queue q
    JOIN hermes_juancabezas_signals s ON s.id = q.signal_id
    WHERE s.verification_status = 'verified_signal';
