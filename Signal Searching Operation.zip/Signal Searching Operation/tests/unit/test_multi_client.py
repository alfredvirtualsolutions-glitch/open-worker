import pytest

from hermes.cli import _client_slug_from_lane_slug
from hermes.config.clients import CLIENTS, validate_client_slug
from hermes.db.repo import _table


def test_validate_client_slug_accepts_known_slugs():
    for slug in CLIENTS:
        assert validate_client_slug(slug) == slug


def test_validate_client_slug_rejects_unknown_slug():
    with pytest.raises(ValueError):
        validate_client_slug("not-a-real-client")


def test_table_name_is_prefixed_per_client():
    assert _table("ryancahill", "signals") == "hermes_ryancahill_signals"
    assert _table("juancabezas", "campaigns") == "hermes_juancabezas_campaigns"


def test_table_rejects_unknown_client_slug():
    with pytest.raises(ValueError):
        _table("some_other_client; DROP TABLE hermes_juancabezas_signals; --", "signals")


def test_client_slug_derived_from_lane_slug_prefix():
    assert _client_slug_from_lane_slug("ryancahill-ca-education-official") == "ryancahill"
    assert _client_slug_from_lane_slug("juancabezas-tx-nursing-news") == "juancabezas"


def test_client_slug_derivation_fails_for_unknown_prefix():
    import click

    with pytest.raises(click.ClickException):
        _client_slug_from_lane_slug("someoneelse-ca-education-official")
