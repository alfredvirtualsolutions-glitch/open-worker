from datetime import date
from uuid import uuid4

from hermes.domain.enums import ProfessionMatchConfidence, RejectionReason, SignalType, VerificationStatus
from hermes.domain.models import ScoreBreakdown, SignalDraft
from hermes.pipeline.acceptance import evaluate_acceptance


def _complete_draft() -> SignalDraft:
    return SignalDraft(
        campaign_id=uuid4(),
        mission_id=uuid4(),
        claim_text="Jane Smith, a teacher at Lincoln Unified School District, announced her retirement.",
        source_url="https://example.org/a",
        raw_claim={},
        profession_match_confidence=ProfessionMatchConfidence.HIGH,
        profession_source_url="https://example.org/a",
        signal_type=SignalType.RETIREMENT_ANNOUNCEMENT,
        state="CA",
        event_date=date(2026, 6, 1),
        individual_signal="Jane Smith",
        organization_signal="Lincoln Unified School District",
        scores=ScoreBreakdown(social_source_score=40, social_evidence_score=45, jobsite_evidence_score=0, cross_source_score=0),
    )


def test_all_conditions_met_verifies_signal():
    draft = _complete_draft()
    status = evaluate_acceptance(draft, score_threshold=50, source_still_live=True)
    assert status == VerificationStatus.VERIFIED_SIGNAL
    assert draft.rejection_reason_code is None


def test_missing_profession_confirmation_rejects():
    draft = _complete_draft()
    draft.profession_source_url = None
    status = evaluate_acceptance(draft, score_threshold=50, source_still_live=True)
    assert status == VerificationStatus.REJECTED
    assert draft.rejection_reason_code == RejectionReason.PROFESSION_NOT_CONFIRMED


def test_dead_source_rejects_even_if_everything_else_passes():
    draft = _complete_draft()
    status = evaluate_acceptance(draft, score_threshold=50, source_still_live=False)
    assert status == VerificationStatus.REJECTED
    assert draft.rejection_reason_code == RejectionReason.SOURCE_NOT_LIVE


def test_below_threshold_rejects():
    draft = _complete_draft()
    status = evaluate_acceptance(draft, score_threshold=1000, source_still_live=True)
    assert status == VerificationStatus.REJECTED
    assert draft.rejection_reason_code == RejectionReason.BELOW_SCORE_THRESHOLD


def test_no_identity_or_organization_rejects():
    draft = _complete_draft()
    draft.individual_signal = None
    draft.organization_signal = None
    status = evaluate_acceptance(draft, score_threshold=50, source_still_live=True)
    assert status == VerificationStatus.REJECTED
    assert draft.rejection_reason_code == RejectionReason.IDENTITY_UNCLEAR
