from hermes.domain.enums import ProfessionMatchConfidence, SignalType, SourceCategory
from hermes.domain.models import SignalDraft
from hermes.pipeline.scorer import score_signal


def _draft(**overrides) -> SignalDraft:
    from uuid import uuid4

    defaults = dict(
        campaign_id=uuid4(),
        mission_id=uuid4(),
        claim_text="claim",
        source_url="https://example.org/a",
        raw_claim={},
    )
    defaults.update(overrides)
    return SignalDraft(**defaults)


def test_official_source_high_confidence_retirement_announcement_scores_highest():
    draft = _draft(
        signal_type=SignalType.RETIREMENT_ANNOUNCEMENT,
        profession_match_confidence=ProfessionMatchConfidence.HIGH,
    )
    breakdown = score_signal(draft, SourceCategory.OFFICIAL_SOURCES)
    assert breakdown.social_source_score == 40
    assert breakdown.social_evidence_score == 30 + 15
    assert breakdown.jobsite_evidence_score == 0
    assert draft.scores is breakdown


def test_unmodeled_source_category_falls_back_to_default_weight():
    draft = _draft(signal_type=None, profession_match_confidence=None)
    breakdown = score_signal(draft, SourceCategory.LINKEDIN_PUBLIC)
    assert breakdown.social_source_score == 10
    assert breakdown.social_evidence_score == 0


def test_cross_source_score_is_capped():
    draft = _draft(signal_type=SignalType.ORG_RESTRUCTURING, profession_match_confidence=None)
    breakdown = score_signal(draft, SourceCategory.NEWS_AND_PRESS, corroborating_sources=10)
    assert breakdown.cross_source_score == 25
