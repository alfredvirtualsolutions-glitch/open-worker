from datetime import date
from uuid import uuid4

from hermes.domain.enums import EmploymentSector, ProfessionGroup, ProfessionMatchConfidence, SignalType
from hermes.domain.models import RawClaim
from hermes.pipeline.classifier import classify_claim


def _classify(text: str, group: ProfessionGroup = ProfessionGroup.EDUCATION):
    return classify_claim(
        RawClaim(text=text, source_url="https://example.org/a", raw={}),
        campaign_id=uuid4(),
        mission_id=uuid4(),
        profession_group=group,
        state_code="CA",
        campaign_segment="test-lane",
    )


def test_no_recognizable_signal_returns_none():
    assert _classify("The district held its annual budget meeting on Tuesday.") is None


def test_full_signal_extracts_everything():
    text = (
        "Jane A. Smith, a longtime teacher at Lincoln Unified School District, "
        "announced her retirement effective June 15, 2026."
    )
    draft = _classify(text)
    assert draft is not None
    assert draft.signal_type == SignalType.RETIREMENT_ANNOUNCEMENT
    assert draft.profession_match_confidence == ProfessionMatchConfidence.MODERATE
    assert draft.organization_signal == "Lincoln Unified School District"
    assert draft.individual_signal == "Jane A. Smith"
    assert draft.event_date == date(2026, 6, 15)
    assert draft.employment_sector == EmploymentSector.PUBLIC
    assert draft.state == "CA"


def test_early_retirement_program_takes_priority_over_generic_retirement_wording():
    text = "The district's early retirement incentive program will let teachers retire early this year."
    draft = _classify(text)
    assert draft is not None
    assert draft.signal_type == SignalType.EARLY_RETIREMENT_PROGRAM


def test_year_only_date_extraction():
    text = "The principal will retire at the end of the 2026 school year."
    draft = _classify(text)
    assert draft is not None
    assert draft.event_date == date(2026, 1, 1)


def test_generic_profession_term_gives_low_confidence():
    text = "A school district employee announced their retirement after 30 years of service."
    draft = _classify(text)
    assert draft is not None
    assert draft.profession_match_confidence == ProfessionMatchConfidence.LOW
    assert draft.profession_source_url is not None


def test_nursing_group_uses_its_own_keyword_table():
    text = "Hospital nurse manager Maria Lopez announced her retirement after 25 years."
    draft = _classify(text, group=ProfessionGroup.NURSING)
    assert draft is not None
    assert draft.target_profession_group == ProfessionGroup.NURSING
    assert draft.profession_match_confidence in (
        ProfessionMatchConfidence.HIGH,
        ProfessionMatchConfidence.MODERATE,
    )
