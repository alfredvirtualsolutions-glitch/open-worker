import pytest

from hermes.config.campaigns import Campaign
from hermes.domain.enums import ProfessionGroup, SourceCategory
from hermes.query.builder import PROFESSION_TERMS, build_queries


def _campaign(**overrides) -> Campaign:
    defaults = dict(
        lane_slug="test-lane",
        client_slug="juancabezas",
        state_code="CA",
        profession_group=ProfessionGroup.EDUCATION,
        source_category=SourceCategory.OFFICIAL_SOURCES,
    )
    defaults.update(overrides)
    return Campaign(**defaults)


def test_build_queries_one_per_profession_term():
    campaign = _campaign()
    queries = build_queries(campaign)
    assert len(queries) == len(PROFESSION_TERMS[ProfessionGroup.EDUCATION])


def test_build_queries_mentions_state_and_source_hint():
    campaign = _campaign(state_code="TX", source_category=SourceCategory.NEWS_AND_PRESS)
    queries = build_queries(campaign)
    assert all("Texas" in q for q in queries)
    assert all("news" in q.lower() for q in queries)


def test_build_queries_covers_every_active_profession_group():
    for group in ProfessionGroup:
        campaign = _campaign(profession_group=group)
        queries = build_queries(campaign)
        assert queries, f"no queries built for {group}"


def test_build_queries_raises_for_unimplemented_source_category():
    campaign = _campaign(source_category=SourceCategory.JOB_BOARDS)
    with pytest.raises(NotImplementedError):
        build_queries(campaign)
