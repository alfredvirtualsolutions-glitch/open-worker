# juan-os-hermes

Daily signal-detection pipeline. Finds public, verifiable retirement/career-
transition signals among specific professional groups and queues them for
**human review** — it does not draft or send outreach, and a profession alone
is never treated as a lead.

This project is a standalone client of [BeHive](../behive) (a third-party
research engine); it does not modify or vendor BeHive's code. BeHive must be
running separately (`docker compose up -d` in the `behive` folder) before any
of the commands below will do anything.

## How a record becomes a "verified signal"

A row only reaches `human_review_queue` when **all** of the following hold:

1. Target profession confirmed, with a source URL for where it was confirmed
2. A current, explicit retirement/transition signal — not just the profession
3. State/location confirmed
4. Publication/event date confirmed
5. The primary source is still live
6. Identity or organization is clear
7. The combined score clears the campaign's threshold

Anything short of that is `rejected` or `archived_research`, not a lead.

## Clients

This Neon database is shared across 4 LEADFORCE clients (see
`hermes/config/clients.py`). Each client has a **fully separate** set of 8
tables (`hermes_{client_slug}_*`, see `schema.sql`) — no shared rows, no
client_slug filter column, because there's no shared table to filter.
Adding a 5th client means: add the slug to `clients.py`, add its lanes to
`hermes/config/campaigns.yaml`, and copy one of the per-client table blocks
in `schema.sql` with the new slug.

| Client | slug | States | Profession groups |
|---|---|---|---|
| Ryan Cahill | `ryancahill` | CA | Education only |
| Don Towns | `dontowns` | CA, TX, AZ | Education only |
| Benjamin Persyn | `benjaminpersyn` | NV | Education only |
| Juan Cabezas | `juancabezas` | TX, CA, FL | All 6 groups (education, nursing, physician, fire_service, public_employee, business_owner) |

"Education" covers K-12 teachers/educators plus colleges and universities.
Only `official_sources` and `news_and_press` source lanes are active —
social platforms and job boards are a later phase — see `../` conversation/
plan history for the phased rollout.

## Setup

```bash
cp .env.example .env   # fill in DATABASE_URL, BEHIVE_BASE_URL
pip install -e ".[dev]"
python -m hermes db init                       # applies schema.sql (all 4 clients' tables)
python -m hermes seed-campaigns                # loads config/campaigns.yaml into each client's tables
```

## Running

```bash
# Submit research queries for one lane (fast, returns immediately) — the
# client is inferred from the lane_slug prefix, e.g. "ryancahill-..."
python -m hermes run --campaign ryancahill-ca-education-official

# Or submit every active lane for one client, optionally filtered by state
python -m hermes run-all --client juancabezas --state CA
python -m hermes run-all --client dontowns

# Separate, short-cadence step: check in-flight BeHive missions across every
# client and, for any that completed, classify/score/persist their claims.
# Intended to run every few minutes (e.g. via its own cron entry).
python -m hermes process-missions

# List signals awaiting a human decision, across all clients (or one)
python -m hermes review-queue
python -m hermes review-queue --client benjaminpersyn
```

## Tests

```bash
pytest tests/unit                 # no network/DB required
pytest tests/integration -m integration   # requires live BeHive + DATABASE_URL
```
